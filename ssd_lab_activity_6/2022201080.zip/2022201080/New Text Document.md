 I have used button for change Mode 
and have used div tags to separate form elements
